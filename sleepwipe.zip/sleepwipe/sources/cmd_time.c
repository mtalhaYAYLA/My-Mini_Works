#include "../includes/sleepwipe.h"

void t_sleep(char *str)
{
    (void)str;
}